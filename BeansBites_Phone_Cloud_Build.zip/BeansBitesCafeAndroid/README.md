# Beans & Bites Café — Android POS v1

Native Android starter project for the Redmi Note 13 Pro+.

## What is included
- Native Kotlin + Jetpack Compose UI
- Offline SQLite local database
- Exactly 6 dine-in locations: T1–T6
- Exactly 3 takeaway locations: Takeaway 1–3
- Full supplied café menu + Water Bottle ₹10
- Global menu search across categories
- Auto-saved active orders
- Quantity +/− controls
- Optional parcel charge: None / ₹5 / ₹10
- Payment: CASH / ONLINE only
- Complete order -> sale history/tally, then clear that location only
- Daily expenses with add/edit/delete and confirmation-ready UI
- Required expense categories
- Daily tally: cash sales, online sales, total sales, cash/online/total expenses, cash in hand
- PDF and Excel-compatible CSV export through Android's file picker
- Database survives app navigation and normal app/device restarts

## Open/build
1. Install Android Studio on Windows.
2. Open this folder: `BeansBitesCafeAndroid`.
3. Let Android Studio download the Gradle/Android dependencies.
4. Connect the Redmi Note 13 Pro+ with USB debugging enabled, or create an emulator.
5. Press Run.
6. To create the installable APK: **Build → Generate App Bundles or APKs → Generate APKs**.

The project targets Android API 35 and has a minimum Android API of 26.

## Important
This environment does not have the Android SDK/Gradle Android toolchain installed, so I am providing the complete Android Studio project rather than claiming a compiled APK was tested here. The Rugtek RP82 USB/ESC-POS printer is intentionally not wired into this first build so printer support cannot compromise order persistence; it can be added as the next module.
