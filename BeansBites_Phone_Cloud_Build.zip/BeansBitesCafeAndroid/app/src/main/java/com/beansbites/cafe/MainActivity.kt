package com.beansbites.cafe

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.*

private val Bg = Color(0xFFF7F7F4)
private val Ink = Color(0xFF17211B)
private val Green = Color(0xFF2F6B45)
private val SoftGreen = Color(0xFFE6F0E8)
private val Card = Color.White

private data class MenuItem(val id: Long, val category: String, val name: String, val price: Int)
private data class CartItem(val menuId: Long, val name: String, val price: Int, val qty: Int)
private data class Expense(val id: Long, val date: String, val category: String, val amount: Int, val payment: String, val notes: String)
private data class Tally(val cashSales: Int, val onlineSales: Int, val cashExp: Int, val onlineExp: Int) {
    val totalSales get() = cashSales + onlineSales
    val totalExpenses get() = cashExp + onlineExp
    val cashInHand get() = cashSales - cashExp
}

class CafeDb(context: Context) : SQLiteOpenHelper(context, "beans_bites.sqlite", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE menu(id INTEGER PRIMARY KEY AUTOINCREMENT, category TEXT NOT NULL, name TEXT NOT NULL, price INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE active_items(location TEXT NOT NULL, menu_id INTEGER NOT NULL, qty INTEGER NOT NULL, PRIMARY KEY(location, menu_id))")
        db.execSQL("CREATE TABLE sales(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, location TEXT NOT NULL, total INTEGER NOT NULL, payment TEXT NOT NULL, parcel INTEGER NOT NULL DEFAULT 0, created_at INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE sale_items(sale_id INTEGER NOT NULL, menu_id INTEGER NOT NULL, name TEXT NOT NULL, price INTEGER NOT NULL, qty INTEGER NOT NULL)")
        db.execSQL("CREATE TABLE expenses(id INTEGER PRIMARY KEY AUTOINCREMENT, date TEXT NOT NULL, category TEXT NOT NULL, amount INTEGER NOT NULL, payment TEXT NOT NULL, notes TEXT NOT NULL DEFAULT '')")
        seed(db)
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}
    private fun seed(db: SQLiteDatabase) {
        val menu = listOf(
            Triple("Cold Coffee","Classic Cold Coffee",50), Triple("Cold Coffee","Strong Cold Coffee",60), Triple("Cold Coffee","Cold Coffee with Crush",60), Triple("Cold Coffee","Mocha Cold Coffee",70), Triple("Cold Coffee","Nutella Cold Coffee",80), Triple("Cold Coffee","Vanilla Cold Coffee",70), Triple("Cold Coffee","Hazelnut Cold Coffee",70), Triple("Cold Coffee","Caramel Cold Coffee",70), Triple("Cold Coffee","Biscoff Cold Coffee (Cafe Special)",110), Triple("Cold Coffee","Icecream n Chocochips Add-on",20),
            Triple("Pav Bhaji & Pulao","Pav Bhaji",70), Triple("Pav Bhaji & Pulao","Cheese Pav Bhaji",95), Triple("Pav Bhaji & Pulao","Spl. Tadka Masala Pav Bhaji (Spicy)",100), Triple("Pav Bhaji & Pulao","Extra Pav",10), Triple("Pav Bhaji & Pulao","Butter Pulao",70), Triple("Pav Bhaji & Pulao","Cheese Pulao",95), Triple("Pav Bhaji & Pulao","Panner Pulao",120), Triple("Pav Bhaji & Pulao","Cheese Panner Pulao",145), Triple("Pav Bhaji & Pulao","Spl. Masala Jeera Pav",20), Triple("Pav Bhaji & Pulao","Masala Bhaji Pav",50),
            Triple("Southern Signatures","Sada Dosa",50), Triple("Southern Signatures","Masala Dosa",70), Triple("Southern Signatures","Mysore Masala Dosa",100), Triple("Southern Signatures","Loni Dosa (3 piece)",80), Triple("Southern Signatures","Onion Uttapam",80), Triple("Southern Signatures","Cut Masala Dosa",80), Triple("Southern Signatures","Special Ghee Roast Dosa",95), Triple("Southern Signatures","Paper Plain Dosa",90), Triple("Southern Signatures","Paper Masala Dosa",100), Triple("Southern Signatures","Plain Uttapam",70), Triple("Southern Signatures","Cheese Add-on",25),
            Triple("Sandwiches","Veg Grilled Mayo Sandwich",90), Triple("Sandwiches","Veg Cheese Grilled Sandwich",100), Triple("Sandwiches","Veg Cheese Masala Grilled",120), Triple("Sandwiches","Cheese Chilly Toast",60), Triple("Sandwiches","Mozrella Cheese Chilly Toast",70), Triple("Sandwiches","Chocolate Sandwich",80),
            Triple("French Fries","Classic French Fries",60), Triple("French Fries","Peri Peri Fries",80), Triple("French Fries","Cheese Peri Peri Fries",90), Triple("French Fries","Cheesy Fries",100),
            Triple("Other","Water Bottle",10)
        )
        menu.forEach { (c,n,p) -> db.execSQL("INSERT INTO menu(category,name,price) VALUES(?,?,?)", arrayOf(c,n,p)) }
    }
    fun menu(): List<MenuItem> = readableDatabase.rawQuery("SELECT id,category,name,price FROM menu ORDER BY id", null).use { c -> buildList { while(c.moveToNext()) add(MenuItem(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3))) } }
    fun cart(location: String): List<CartItem> = readableDatabase.rawQuery("SELECT m.id,m.name,m.price,a.qty FROM active_items a JOIN menu m ON m.id=a.menu_id WHERE a.location=? ORDER BY m.id", arrayOf(location)).use { c -> buildList { while(c.moveToNext()) add(CartItem(c.getLong(0),c.getString(1),c.getInt(2),c.getInt(3))) } }
    fun setQty(location:String, item:MenuItem, qty:Int) { val db=writableDatabase; if(qty<=0) db.delete("active_items","location=? AND menu_id=?",arrayOf(location,item.id.toString())) else db.execSQL("INSERT OR REPLACE INTO active_items(location,menu_id,qty) VALUES(?,?,?)",arrayOf(location,item.id,qty)) }
    fun complete(location:String,payment:String,parcel:Int): Boolean {
        val db=writableDatabase; db.beginTransaction()
        try { val items=cart(location); if(items.isEmpty()) return false; val total=items.sumOf{it.price*it.qty}+parcel; val date=today(); val st=db.compileStatement("INSERT INTO sales(date,location,total,payment,parcel,created_at) VALUES(?,?,?,?,?,?)"); st.bindString(1,date);st.bindString(2,location);st.bindLong(3,total.toLong());st.bindString(4,payment);st.bindLong(5,parcel.toLong());st.bindLong(6,System.currentTimeMillis());val saleId=st.executeInsert(); items.forEach{db.execSQL("INSERT INTO sale_items(sale_id,menu_id,name,price,qty) VALUES(?,?,?,?,?)",arrayOf(saleId,it.menuId,it.name,it.price,it.qty))}; db.delete("active_items","location=?",arrayOf(location)); db.setTransactionSuccessful(); return true } finally { db.endTransaction() }
    }
    fun addExpense(category:String,amount:Int,payment:String,notes:String) { val db=writableDatabase; db.execSQL("INSERT INTO expenses(date,category,amount,payment,notes) VALUES(?,?,?,?,?)",arrayOf(today(),category,amount,payment,notes)) }
    fun updateExpense(id:Long,category:String,amount:Int,payment:String,notes:String) { writableDatabase.execSQL("UPDATE expenses SET category=?,amount=?,payment=?,notes=? WHERE id=?",arrayOf(category,amount,payment,notes,id)) }
    fun deleteExpense(id:Long) { writableDatabase.delete("expenses","id=?",arrayOf(id.toString())) }
    fun expenses(date:String):List<Expense> = readableDatabase.rawQuery("SELECT id,date,category,amount,payment,notes FROM expenses WHERE date=? ORDER BY id DESC",arrayOf(date)).use{c->buildList{while(c.moveToNext())add(Expense(c.getLong(0),c.getString(1),c.getString(2),c.getInt(3),c.getString(4),c.getString(5)))}}
    fun tally(date:String):Tally { readableDatabase.rawQuery("SELECT COALESCE(SUM(CASE WHEN payment='CASH' THEN total ELSE 0 END),0),COALESCE(SUM(CASE WHEN payment='ONLINE' THEN total ELSE 0 END),0) FROM sales WHERE date=?",arrayOf(date)).use{c->c.moveToFirst(); val cs=c.getInt(0);val os=c.getInt(1); readableDatabase.rawQuery("SELECT COALESCE(SUM(CASE WHEN payment='CASH' THEN amount ELSE 0 END),0),COALESCE(SUM(CASE WHEN payment='ONLINE' THEN amount ELSE 0 END),0) FROM expenses WHERE date=?",arrayOf(date)).use{e->e.moveToFirst();return Tally(cs,os,e.getInt(0),e.getInt(1))}} }
    fun sales(date:String):List<Array<String>> = readableDatabase.rawQuery("SELECT location,total,payment,created_at FROM sales WHERE date=? ORDER BY created_at DESC",arrayOf(date)).use{c->buildList{while(c.moveToNext())add(arrayOf(c.getString(0),"₹${c.getInt(1)}",c.getString(2),fmtTime(c.getLong(3))))}}
    companion object { fun today()=SimpleDateFormat("yyyy-MM-dd",Locale.US).format(Date()); fun fmtTime(t:Long)=SimpleDateFormat("hh:mm a",Locale.US).format(Date(t)) }
}

class MainActivity : ComponentActivity() {
    private lateinit var db: CafeDb
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); db=CafeDb(this); setContent { CafeApp(db) } }
}

@Composable fun CafeApp(db:CafeDb) {
    var tab by remember { mutableStateOf(0) }
    var refresh by remember { mutableIntStateOf(0) }
    var selected by remember { mutableStateOf<String?>(null) }
    MaterialTheme(colorScheme=lightColorScheme(primary=Green,background=Bg,surface=Card)) {
        Scaffold(containerColor=Bg, bottomBar={ if(selected==null) BottomBar(tab){tab=it} }) { pad ->
            Box(Modifier.fillMaxSize().padding(pad)) {
                if(selected!=null) OrderScreen(db,selected!!,{selected=null;refresh++},{refresh++})
                else when(tab){0->OrdersScreen(db,refresh,{selected=it});1->ExpensesScreen(db,refresh){refresh++};2->TallyScreen(db,refresh)}
            }
        }
    }
}

@Composable fun Header(title:String,subtitle:String="") { Column(Modifier.fillMaxWidth().padding(horizontal=18.dp,vertical=14.dp)){Text(title,fontSize=25.sp,fontWeight=FontWeight.Bold,color=Ink);if(subtitle.isNotBlank())Text(subtitle,fontSize=13.sp,color=Color.Gray)} }

@Composable fun OrdersScreen(db:CafeDb,refresh:Int,onOpen:(String)->Unit){
    Column(Modifier.fillMaxSize().padding(bottom=76.dp)){Header("BEANS & BITES CAFÉ","Fast offline orders • data saved automatically")
        LazyColumn(contentPadding=PaddingValues(horizontal=16.dp,vertical=4.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
            item{Text("DINE-IN",fontWeight=FontWeight.Bold,color=Green,modifier=Modifier.padding(vertical=5.dp))}
            items((1..6).toList()){ n->LocationCard("T$n",db.cart("T$n").sumOf{it.qty},onOpen) }
            item{Text("TAKEAWAY",fontWeight=FontWeight.Bold,color=Green,modifier=Modifier.padding(top=12.dp,bottom=5.dp))}
            items((1..3).toList()){ n->LocationCard("Takeaway $n",db.cart("Takeaway $n").sumOf{it.qty},onOpen) }
        }
    }
}
@Composable fun LocationCard(name:String,count:Int,onOpen:(String)->Unit){Card(Modifier.fillMaxWidth().clickable{onOpen(name)},shape=RoundedCornerShape(18.dp)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(name,fontSize=19.sp,fontWeight=FontWeight.Bold,color=Ink);Text(if(count==0)"Available" else "$count item${if(count>1)"s" else ""} • Occupied",color=if(count==0)Color.Gray else Green,fontSize=13.sp)}Text(if(count==0)"OPEN" else "OPEN ORDER",fontSize=12.sp,fontWeight=FontWeight.Bold,color=Green)}}}

@Composable fun OrderScreen(db:CafeDb,location:String,onBack:()->Unit,onChanged:()->Unit){
    var query by remember{mutableStateOf("")}; var category by remember{mutableStateOf("All")}; var parcel by remember{mutableIntStateOf(0)}; var payment by remember{mutableStateOf("CASH")}; var cart by remember{mutableStateOf(db.cart(location))}; var confirm by remember{mutableStateOf(false)}
    val all=db.menu(); val cats=listOf("All")+all.map{it.category}.distinct(); val shown=all.filter{(category=="All"||it.category==category)&&(query.isBlank()||it.name.contains(query,true)||it.category.contains(query,true))}; val total=cart.sumOf{it.price*it.qty}+parcel
    Column(Modifier.fillMaxSize().padding(bottom=8.dp)){Row(Modifier.fillMaxWidth().padding(12.dp),verticalAlignment=Alignment.CenterVertically){Text("‹",fontSize=34.sp,modifier=Modifier.clickable{onBack()}.padding(horizontal=8.dp));Column{Text(location,fontSize=22.sp,fontWeight=FontWeight.Bold,color=Ink);Text("Auto-saved order",fontSize=12.sp,color=Color.Gray)}}
        OutlinedTextField(query,{query=it},Modifier.fillMaxWidth().padding(horizontal=14.dp),placeholder={Text("Search any menu item…")},singleLine=true,shape=RoundedCornerShape(14.dp))
        Row(Modifier.fillMaxWidth().padding(10.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)){cats.take(4).forEach{c->FilterChip(selected=category==c,onClick={category=c},label={Text(c, maxLines=1)})}}
        if(cats.size>4) Row(Modifier.fillMaxWidth().padding(horizontal=10.dp),horizontalArrangement=Arrangement.spacedBy(7.dp)){cats.drop(4).forEach{c->FilterChip(selected=category==c,onClick={category=c},label={Text(c,maxLines=1)})}}
        Row(Modifier.fillMaxWidth().weight(1f)){LazyColumn(Modifier.weight(1f).padding(start=12.dp,end=6.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(shown){m->MenuCard(m){db.setQty(location,m,(cart.find{it.menuId==m.id}?.qty?:0)+1);cart=db.cart(location);onChanged()}}};Column(Modifier.width(150.dp).padding(end=12.dp)){Text("ORDER",fontWeight=FontWeight.Bold,color=Green,modifier=Modifier.padding(4.dp));LazyColumn(Modifier.weight(1f)){items(cart){i->Row(Modifier.fillMaxWidth().padding(vertical=5.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(i.name,maxLines=2,fontSize=12.sp);Text("₹${i.price} × ${i.qty}",fontSize=11.sp,color=Color.Gray);Row{TextButton(onClick={all.find{m->m.id==i.menuId}?.let{m->db.setQty(location,m,i.qty-1);cart=db.cart(location);onChanged()}}){Text("−")};TextButton(onClick={all.find{m->m.id==i.menuId}?.let{m->db.setQty(location,m,i.qty+1);cart=db.cart(location);onChanged()}}){Text("+")}}};Text("₹${i.price*i.qty}",fontSize=12.sp,fontWeight=FontWeight.Bold)}}}}
        }
        Card(Modifier.fillMaxWidth().padding(10.dp),shape=RoundedCornerShape(18.dp)){Column(Modifier.padding(12.dp)){Text("Parcel charge",fontWeight=FontWeight.Bold);Row(horizontalArrangement=Arrangement.spacedBy(7.dp)){FilterChip(selected=parcel==0,onClick={parcel=0},label={Text("None")});FilterChip(selected=parcel==5,onClick={parcel=5},label={Text("₹5")});FilterChip(selected=parcel==10,onClick={parcel=10},label={Text("₹10")})};Row(verticalAlignment=Alignment.CenterVertically){Text("Payment",fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));FilterChip(selected=payment=="CASH",onClick={payment="CASH"},label={Text("CASH")});Spacer(Modifier.width(6.dp));FilterChip(selected=payment=="ONLINE",onClick={payment="ONLINE"},label={Text("ONLINE")})};Row(Modifier.padding(top=7.dp),verticalAlignment=Alignment.CenterVertically){Text("Total",fontSize=18.sp,fontWeight=FontWeight.Bold,modifier=Modifier.weight(1f));Text("₹$total",fontSize=21.sp,fontWeight=FontWeight.Bold,color=Green);Spacer(Modifier.width(10.dp));Button(onClick={confirm=true},enabled=cart.isNotEmpty(),shape=RoundedCornerShape(12.dp)){Text("COMPLETE")}}}}
    }
    if(confirm) AlertDialog(onDismissRequest={confirm=false},title={Text("Complete order?")},text={Text("${location} • ₹$total • $payment\nThe active order will be saved to today's sales and cleared only after success.")},confirmButton={Button(onClick={if(db.complete(location,payment,parcel)){confirm=false;onChanged();onBack()}},){Text("Complete")}},dismissButton={TextButton(onClick={confirm=false}){Text("Cancel")}})
}
@Composable fun MenuCard(m:MenuItem,onAdd:()->Unit){Card(Modifier.fillMaxWidth().clickable{onAdd()},shape=RoundedCornerShape(14.dp)){Row(Modifier.padding(11.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(m.name,fontSize=14.sp,fontWeight=FontWeight.Medium,color=Ink);Text(m.category,fontSize=10.sp,color=Color.Gray)}Text("₹${m.price}",fontWeight=FontWeight.Bold,color=Green)}}}

@Composable fun ExpensesScreen(db:CafeDb,refresh:Int,onChanged:()->Unit){var editor by remember{mutableStateOf<Expense?>(null)};val list=db.expenses(CafeDb.today());Column(Modifier.fillMaxSize().padding(bottom=8.dp)){Header("DAILY EXPENSES","Today • ${CafeDb.today()}");Button(onClick={editor=Expense(0,CafeDb.today(),"Kirana",0,"CASH","")},Modifier.fillMaxWidth().padding(horizontal=16.dp),shape=RoundedCornerShape(14.dp)){Text("+ ADD EXPENSE")};LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){items(list){e->Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(14.dp)){Row(Modifier.padding(12.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(e.category,fontWeight=FontWeight.Bold);Text("${e.payment}${if(e.notes.isNotBlank())" • ${e.notes}" else ""}",fontSize=12.sp,color=Color.Gray)}Text("₹${e.amount}",fontWeight=FontWeight.Bold);TextButton(onClick={editor=e}){Text("Edit")};TextButton(onClick={db.deleteExpense(e.id);onChanged()}){Text("Delete")}}}}}}
    editor?.let{e->AddExpenseDialog(db,e,{editor=null;onChanged()},{editor=null})}
}
@Composable fun AddExpenseDialog(db:CafeDb,existing:Expense,onSaved:()->Unit,onCancel:()->Unit){var category by remember(existing){mutableStateOf(existing.category)};var amount by remember(existing){mutableStateOf(if(existing.amount==0)"" else existing.amount.toString())};var payment by remember(existing){mutableStateOf(existing.payment)};var notes by remember(existing){mutableStateOf(existing.notes)};val cats=listOf("Kirana","Pav Bhaji/Food Material","Dairy","Vegetables","Disposables","Water Bottle","Cylinder","Rent","Electricity","Worker Salary","Maid Salary","Cook Salary","Garbage Picker","Other");AlertDialog(onDismissRequest=onCancel,title={Text(if(existing.id==0L)"Add Expense" else "Edit Expense")},text={Column(verticalArrangement=Arrangement.spacedBy(7.dp)){Text("Category",fontWeight=FontWeight.Bold);var expanded by remember{mutableStateOf(false)};Box{OutlinedButton(onClick={expanded=true},Modifier.fillMaxWidth()){Text(category)};DropdownMenu(expanded=expanded,onDismissRequest={expanded=false}){cats.forEach{c->DropdownMenuItem(text={Text(c)},onClick={category=c;expanded=false})}}};OutlinedTextField(amount,{amount=it.filter(Char::isDigit)},Modifier.fillMaxWidth(),label={Text("Amount ₹")});Row{FilterChip(selected=payment=="CASH",onClick={payment="CASH"},label={Text("CASH")});Spacer(Modifier.width(6.dp));FilterChip(selected=payment=="ONLINE",onClick={payment="ONLINE"},label={Text("ONLINE")})};OutlinedTextField(notes,{notes=it},Modifier.fillMaxWidth(),label={Text("Notes")})}},confirmButton={Button(enabled=amount.toIntOrNull()!=null&&amount.toInt()>0,onClick={if(existing.id==0L)db.addExpense(category,amount.toInt(),payment,notes) else db.updateExpense(existing.id,category,amount.toInt(),payment,notes);onSaved()}){Text("Save")}},dismissButton={TextButton(onClick=onCancel){Text("Cancel")}})}

@Composable fun TallyScreen(db:CafeDb,refresh:Int){var date by remember{mutableStateOf(CafeDb.today())};val tally=db.tally(date);val expenses=db.expenses(date);val sales=db.sales(date);var exportType by remember{mutableStateOf("")};val launcher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")){uri->if(uri!=null){val bytes=if(exportType=="pdf")pdfReport(date,tally,sales,expenses) else csvReport(date,tally,sales,expenses);LocalContext.current.contentResolver.openOutputStream(uri)?.use{it.write(bytes)}}};Column(Modifier.fillMaxSize().padding(bottom=76.dp)){Header("DAILY TALLY","Select a date to see sales, expenses and cash in hand");OutlinedTextField(date,{date=it},Modifier.fillMaxWidth().padding(horizontal=16.dp),label={Text("Date YYYY-MM-DD")},singleLine=true);LazyColumn(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){item{SummaryCard("CASH SALES",tally.cashSales);SummaryCard("ONLINE SALES",tally.onlineSales);SummaryCard("TOTAL SALES",tally.totalSales);SummaryCard("CASH EXPENSES",tally.cashExp);SummaryCard("ONLINE EXPENSES",tally.onlineExp);SummaryCard("TOTAL EXPENSES",tally.totalExpenses);SummaryCard("CASH IN HAND",tally.cashInHand)};item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick={exportType="pdf";launcher.launch("beans_bites_tally_$date.pdf")},Modifier.weight(1f)){Text("PDF")};Button(onClick={exportType="csv";launcher.launch("beans_bites_tally_$date.csv")},Modifier.weight(1f)){Text("EXCEL / CSV")}}};item{Text("SALES",fontWeight=FontWeight.Bold,color=Green)};items(sales){s->Text("${s[0]} • ${s[3]} • ${s[2]}  ${s[1]}",fontSize=13.sp)};item{Text("EXPENSES",fontWeight=FontWeight.Bold,color=Green,modifier=Modifier.padding(top=8.dp))};items(expenses){e->Text("${e.category} • ${e.payment}  ₹${e.amount}",fontSize=13.sp)}}}
}
@Composable fun SummaryCard(label:String,value:Int){Card(Modifier.fillMaxWidth(),shape=RoundedCornerShape(15.dp)){Row(Modifier.padding(15.dp),verticalAlignment=Alignment.CenterVertically){Text(label,fontWeight=FontWeight.SemiBold,modifier=Modifier.weight(1f));Text("₹$value",fontSize=19.sp,fontWeight=FontWeight.Bold,color=Green)}}}

@Composable fun BottomBar(tab:Int,onTab:(Int)->Unit){NavigationBar{NavigationBarItem(selected=tab==0,onClick={onTab(0)},icon={Text("▣")},label={Text("Orders")});NavigationBarItem(selected=tab==1,onClick={onTab(1)},icon={Text("₹")},label={Text("Expenses")});NavigationBarItem(selected=tab==2,onClick={onTab(2)},icon={Text("▤")},label={Text("Daily Tally")})}}

private fun csvReport(date:String,t:Tally,sales:List<Array<String>>,expenses:List<Expense>):ByteArray { val s=StringBuilder();s.append("BEANS & BITES CAFÉ DAILY TALLY,$date\n\nMetric,Amount\nCash Sales,${t.cashSales}\nOnline Sales,${t.onlineSales}\nTotal Sales,${t.totalSales}\nCash Expenses,${t.cashExp}\nOnline Expenses,${t.onlineExp}\nTotal Expenses,${t.totalExpenses}\nCash In Hand,${t.cashInHand}\n\nSALES\nLocation,Total,Payment,Time\n");sales.forEach{a->s.append(a.joinToString(",")).append('\n')};s.append("\nEXPENSES\nCategory,Amount,Payment,Notes\n");expenses.forEach{e->s.append("${e.category},${e.amount},${e.payment},\"${e.notes.replace("\"","\"\"")}\"\n")};return s.toString().toByteArray(Charsets.UTF_8)}
private fun pdfReport(date:String,t:Tally,sales:List<Array<String>>,expenses:List<Expense>):ByteArray { val doc=PdfDocument();val page=doc.startPage(PdfDocument.PageInfo.Builder(595,842,1).create());val p=Paint();p.textSize=18f;p.isFakeBoldText=true;var y=45f;page.canvas.drawText("BEANS & BITES CAFÉ",32f,y,p);p.textSize=12f;p.isFakeBoldText=false;y+=24;page.canvas.drawText("Daily Tally • $date",32f,y,p);y+=28;listOf("Cash Sales" to t.cashSales,"Online Sales" to t.onlineSales,"Total Sales" to t.totalSales,"Cash Expenses" to t.cashExp,"Online Expenses" to t.onlineExp,"Total Expenses" to t.totalExpenses,"Cash In Hand" to t.cashInHand).forEach{(k,v)->page.canvas.drawText(k,40f,y,p);page.canvas.drawText("₹$v",430f,y,p);y+=20};y+=15;p.isFakeBoldText=true;page.canvas.drawText("Sales",32f,y,p);p.isFakeBoldText=false;y+=20;sales.take(20).forEach{a->page.canvas.drawText("${a[0]}  ${a[1]}  ${a[2]}  ${a[3]}",32f,y,p);y+=16};y+=12;p.isFakeBoldText=true;page.canvas.drawText("Expenses",32f,y,p);p.isFakeBoldText=false;y+=20;expenses.take(20).forEach{e->page.canvas.drawText("${e.category}  ₹${e.amount}  ${e.payment}",32f,y,p);y+=16};doc.finishPage(page);val out=ByteArrayOutputStream();doc.writeTo(out);doc.close();return out.toByteArray()}
